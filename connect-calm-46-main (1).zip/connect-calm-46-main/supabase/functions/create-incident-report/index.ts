import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { corsHeaders } from '../_shared/cors.ts'

interface ReportRequest {
  title: string
  description: string
  communicationId?: string
  evidenceFiles?: File[]
  severity?: 'low' | 'medium' | 'high' | 'critical'
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get user from authorization header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    )

    if (authError || !user) {
      throw new Error('Invalid authorization')
    }

    const requestData: ReportRequest = await req.json()
    
    // Handle file uploads if provided
    let evidenceUrls: string[] = []
    if (requestData.evidenceFiles && requestData.evidenceFiles.length > 0) {
      // In a real implementation, you would upload files to Supabase Storage
      // For now, we'll just simulate this
      evidenceUrls = requestData.evidenceFiles.map((_, index) => 
        `evidence/${user.id}/${Date.now()}_${index}`
      )
    }

    // Create incident report
    const { data: report, error: insertError } = await supabase
      .from('incident_reports')
      .insert({
        reporter_id: user.id,
        title: requestData.title,
        description: requestData.description,
        communication_id: requestData.communicationId || null,
        evidence_urls: evidenceUrls,
        severity: requestData.severity || 'medium',
        status: 'pending'
      })
      .select()
      .single()

    if (insertError) {
      throw insertError
    }

    // Create notification alert for admins
    const { error: alertError } = await supabase
      .from('alerts')
      .insert({
        user_id: user.id,
        alert_type: 'new_report',
        message: `New incident report: ${requestData.title}`,
        severity: requestData.severity || 'medium'
      })

    return new Response(
      JSON.stringify({
        success: true,
        report_id: report.id,
        message: 'Report created successfully'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    console.error('Error creating incident report:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})