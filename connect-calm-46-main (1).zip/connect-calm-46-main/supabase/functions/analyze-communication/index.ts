import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { corsHeaders } from '../_shared/cors.ts'

interface AnalysisRequest {
  message: string
  communicationType: 'email' | 'chat' | 'social_media' | 'sms'
  senderInfo?: any
  recipientInfo?: any
  platformMetadata?: any
}

interface AnalysisResult {
  isHarassment: boolean
  severityScore: number
  flaggedReasons: string[]
  confidence: number
  detectedPatterns: string[]
}

// Mock AI analysis function - replace with actual AI service
function analyzeMessage(message: string): AnalysisResult {
  const harassmentKeywords = [
    'threat', 'kill', 'harm', 'stupid', 'idiot', 'hate you', 
    'worthless', 'ugly', 'fat', 'die', 'suicide', 'stalking',
    'following you', 'watching you', 'revenge', 'payback'
  ]
  
  const threatKeywords = [
    'kill', 'murder', 'harm', 'hurt', 'violence', 'gun', 'knife',
    'bomb', 'attack', 'destroy', 'revenge', 'payback'
  ]
  
  const personalAttacks = [
    'stupid', 'idiot', 'worthless', 'ugly', 'fat', 'loser',
    'pathetic', 'disgusting', 'horrible', 'terrible'
  ]

  const lowerMessage = message.toLowerCase()
  const flaggedReasons: string[] = []
  const detectedPatterns: string[] = []
  let severityScore = 0

  // Check for threats
  for (const keyword of threatKeywords) {
    if (lowerMessage.includes(keyword)) {
      flaggedReasons.push('Threat detected')
      detectedPatterns.push(`Threat language: "${keyword}"`)
      severityScore += 0.4
    }
  }

  // Check for personal attacks
  for (const keyword of personalAttacks) {
    if (lowerMessage.includes(keyword)) {
      flaggedReasons.push('Personal attack')
      detectedPatterns.push(`Offensive language: "${keyword}"`)
      severityScore += 0.2
    }
  }

  // Check for harassment patterns
  for (const keyword of harassmentKeywords) {
    if (lowerMessage.includes(keyword)) {
      if (!flaggedReasons.includes('Harassment detected')) {
        flaggedReasons.push('Harassment detected')
      }
      detectedPatterns.push(`Harassment pattern: "${keyword}"`)
      severityScore += 0.15
    }
  }

  // Check for repeated characters (indicating shouting/aggression)
  if (/(.)\1{3,}/.test(message)) {
    flaggedReasons.push('Aggressive tone')
    detectedPatterns.push('Excessive repetition detected')
    severityScore += 0.1
  }

  // Check for excessive caps
  const capsRatio = (message.match(/[A-Z]/g) || []).length / message.length
  if (capsRatio > 0.5 && message.length > 10) {
    flaggedReasons.push('Aggressive tone')
    detectedPatterns.push('Excessive capitalization')
    severityScore += 0.1
  }

  // Cap severity score at 1.0
  severityScore = Math.min(severityScore, 1.0)

  const isHarassment = severityScore > 0.3
  const confidence = Math.min(severityScore * 2, 1.0)

  return {
    isHarassment,
    severityScore,
    flaggedReasons: [...new Set(flaggedReasons)],
    confidence,
    detectedPatterns
  }
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get user from authorization header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    )

    if (authError || !user) {
      throw new Error('Invalid authorization')
    }

    const requestData: AnalysisRequest = await req.json()
    
    // Perform AI analysis
    const analysis = analyzeMessage(requestData.message)

    // Store communication record
    const { data: communication, error: insertError } = await supabase
      .from('communications')
      .insert({
        user_id: user.id,
        message_content: requestData.message,
        communication_type: requestData.communicationType,
        sender_info: requestData.senderInfo,
        recipient_info: requestData.recipientInfo,
        platform_metadata: requestData.platformMetadata,
        ai_analysis: analysis,
        severity_score: analysis.severityScore,
        is_flagged: analysis.isHarassment,
        flagged_reasons: analysis.flaggedReasons
      })
      .select()
      .single()

    if (insertError) {
      console.error('Database insert error:', insertError)
      throw insertError
    }

    // Create alert if harassment detected
    if (analysis.isHarassment && communication) {
      const { error: alertError } = await supabase
        .from('alerts')
        .insert({
          user_id: user.id,
          communication_id: communication.id,
          alert_type: 'harassment_detected',
          message: `Potential harassment detected with ${Math.round(analysis.severityScore * 100)}% severity`,
          severity: analysis.severityScore > 0.7 ? 'high' : analysis.severityScore > 0.5 ? 'medium' : 'low'
        })

      if (alertError) {
        console.error('Alert creation error:', alertError)
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        communication_id: communication.id,
        analysis
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    console.error('Error in analyze-communication:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})