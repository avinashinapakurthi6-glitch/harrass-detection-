import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { corsHeaders } from '../_shared/cors.ts'

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get user from authorization header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    )

    if (authError || !user) {
      throw new Error('Invalid authorization')
    }

    // Get recent flagged communications
    const { data: flaggedMessages, error: messagesError } = await supabase
      .from('communications')
      .select('*')
      .eq('user_id', user.id)
      .eq('is_flagged', true)
      .order('created_at', { ascending: false })
      .limit(20)

    if (messagesError) throw messagesError

    // Get unread alerts
    const { data: alerts, error: alertsError } = await supabase
      .from('alerts')
      .select('*')
      .eq('user_id', user.id)
      .eq('is_read', false)
      .order('created_at', { ascending: false })
      .limit(10)

    if (alertsError) throw alertsError

    // Get recent incident reports
    const { data: reports, error: reportsError } = await supabase
      .from('incident_reports')
      .select('*')
      .eq('reporter_id', user.id)
      .order('created_at', { ascending: false })
      .limit(10)

    if (reportsError) throw reportsError

    // Get statistics for the last 30 days
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
    
    const { data: stats, error: statsError } = await supabase
      .from('communications')
      .select('severity_score, is_flagged, created_at')
      .eq('user_id', user.id)
      .gte('created_at', thirtyDaysAgo)

    if (statsError) throw statsError

    // Calculate dashboard metrics
    const totalMessages = stats.length
    const flaggedCount = stats.filter(s => s.is_flagged).length
    const avgSeverity = stats.length > 0 
      ? stats.reduce((sum, s) => sum + (s.severity_score || 0), 0) / stats.length 
      : 0

    // Group by day for trend chart
    const dailyStats = stats.reduce((acc, msg) => {
      const date = new Date(msg.created_at).toISOString().split('T')[0]
      if (!acc[date]) {
        acc[date] = { total: 0, flagged: 0, severitySum: 0 }
      }
      acc[date].total++
      if (msg.is_flagged) acc[date].flagged++
      acc[date].severitySum += msg.severity_score || 0
      return acc
    }, {} as Record<string, { total: number; flagged: number; severitySum: number }>)

    const trendData = Object.entries(dailyStats).map(([date, data]) => ({
      date,
      total: data.total,
      flagged: data.flagged,
      avgSeverity: data.total > 0 ? data.severitySum / data.total : 0
    })).sort((a, b) => a.date.localeCompare(b.date))

    return new Response(
      JSON.stringify({
        success: true,
        data: {
          flaggedMessages,
          alerts,
          reports,
          stats: {
            totalMessages,
            flaggedCount,
            avgSeverity: Math.round(avgSeverity * 100) / 100,
            flaggedPercentage: totalMessages > 0 ? Math.round((flaggedCount / totalMessages) * 100) : 0
          },
          trendData
        }
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    console.error('Error getting dashboard data:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})