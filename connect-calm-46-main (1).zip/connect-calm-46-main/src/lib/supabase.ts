import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database types
export interface Profile {
  id: string
  email: string
  full_name?: string
  avatar_url?: string
  is_admin: boolean
  notification_preferences: {
    email: boolean
    push: boolean
    sms: boolean
  }
  monitored_channels: string[]
  created_at: string
  updated_at: string
}

export interface Communication {
  id: string
  user_id: string
  message_content: string
  communication_type: 'email' | 'chat' | 'social_media' | 'sms'
  sender_info?: any
  recipient_info?: any
  platform_metadata?: any
  ai_analysis?: {
    isHarassment: boolean
    severityScore: number
    flaggedReasons: string[]
    confidence: number
    detectedPatterns: string[]
  }
  severity_score: number
  is_flagged: boolean
  flagged_reasons: string[]
  created_at: string
}

export interface IncidentReport {
  id: string
  reporter_id: string
  title: string
  description: string
  communication_id?: string
  evidence_urls: string[]
  status: 'pending' | 'investigating' | 'resolved' | 'dismissed'
  severity: 'low' | 'medium' | 'high' | 'critical'
  assigned_to?: string
  resolution_notes?: string
  created_at: string
  updated_at: string
}

export interface Alert {
  id: string
  user_id: string
  communication_id?: string
  alert_type: string
  message: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  is_read: boolean
  created_at: string
}

export interface UserSettings {
  id: string
  user_id: string
  detection_sensitivity: number
  auto_block_enabled: boolean
  real_time_monitoring: boolean
  keywords_to_monitor: string[]
  blocked_contacts: any[]
  created_at: string
  updated_at: string
}