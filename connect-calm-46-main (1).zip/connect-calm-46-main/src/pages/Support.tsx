import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  HelpCircle, 
  MessageSquare, 
  Mail, 
  Phone, 
  Clock, 
  Search,
  CheckCircle,
  AlertTriangle,
  BookOpen,
  Users,
  Shield,
  Settings
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const faqCategories = [
  {
    id: "general",
    title: "General Questions",
    icon: HelpCircle,
    questions: [
      {
        question: "What is SafeGuard AI and how does it work?",
        answer: "SafeGuard AI is an advanced harassment detection system that uses machine learning to monitor digital communications in real-time. It analyzes text patterns, context, and behavioral indicators to identify potential threats and abusive behavior across email, chat, social media, and other platforms."
      },
      {
        question: "Which platforms does SafeGuard AI monitor?",
        answer: "We currently support email systems, chat applications (Slack, Discord, Teams), social media platforms (Twitter, Facebook, LinkedIn), and forum communities. Our API can also integrate with custom applications and communication systems."
      },
      {
        question: "How accurate is the AI detection system?",
        answer: "Our AI system maintains a 94.8% accuracy rate with less than 2% false positives. The system continuously learns and improves from user feedback and new data patterns, with accuracy rates improving monthly."
      }
    ]
  },
  {
    id: "privacy",
    title: "Privacy & Security",
    icon: Shield,
    questions: [
      {
        question: "How is my data protected?",
        answer: "All data is encrypted end-to-end using AES-256 encryption. We use a zero-knowledge architecture, meaning we analyze patterns without storing personal content. All data processing complies with GDPR, CCPA, and other privacy regulations."
      },
      {
        question: "Do you store my communications?",
        answer: "No, we do not store the content of your communications. Our AI analyzes patterns and metadata in real-time, then discards the content. Only threat detection results and anonymous behavioral patterns are retained for system improvement."
      },
      {
        question: "Who has access to my monitoring data?",
        answer: "Only authorized personnel involved in threat assessment can access anonymized threat data. Personal identifiable information is never shared without explicit consent, except in cases of imminent danger where legal reporting is required."
      }
    ]
  },
  {
    id: "technical",
    title: "Technical Support",
    icon: Settings,
    questions: [
      {
        question: "How do I integrate SafeGuard AI with my existing systems?",
        answer: "We provide REST APIs, webhooks, and pre-built integrations for popular platforms. Our technical team offers white-glove onboarding with custom integration support. Documentation and SDKs are available for developers."
      },
      {
        question: "What happens when a threat is detected?",
        answer: "When a threat is detected, you receive real-time alerts via your preferred channels (email, SMS, app notification). The system provides threat context, severity level, and recommended actions. You can then review, escalate, or take protective measures."
      },
      {
        question: "Can I customize detection sensitivity?",
        answer: "Yes, you can adjust detection sensitivity based on your needs. We offer predefined profiles (strict, balanced, permissive) and custom configuration for specific types of content, contexts, and user groups."
      }
    ]
  },
  {
    id: "billing",
    title: "Billing & Plans",
    icon: Settings,
    questions: [
      {
        question: "What plans are available?",
        answer: "We offer individual, team, and enterprise plans. Individual plans start at $9.99/month, team plans at $29.99/month per user, and enterprise plans are custom-priced based on volume and features required."
      },
      {
        question: "Is there a free trial?",
        answer: "Yes, we offer a 14-day free trial with full access to all features. No credit card required to start. You can monitor up to 1,000 communications during the trial period."
      },
      {
        question: "Can I cancel anytime?",
        answer: "Absolutely. You can cancel your subscription at any time with no cancellation fees. Your data protection continues until the end of your billing period, and you can export all reports and data."
      }
    ]
  }
];

const supportChannels = [
  {
    title: "Live Chat",
    description: "Get instant help from our support team",
    availability: "24/7",
    responseTime: "< 2 minutes",
    icon: MessageSquare,
    recommended: true
  },
  {
    title: "Email Support",
    description: "Detailed support for complex issues",
    availability: "24/7",
    responseTime: "< 4 hours",
    icon: Mail,
    recommended: false
  },
  {
    title: "Phone Support",
    description: "Direct support for urgent matters",
    availability: "Mon-Fri 9AM-6PM PST",
    responseTime: "Immediate",
    icon: Phone,
    recommended: false
  }
];

export default function Support() {
  const [searchQuery, setSearchQuery] = useState("");
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    category: "",
    subject: "",
    message: "",
    priority: "normal"
  });
  const { toast } = useToast();

  const filteredFAQs = faqCategories.map(category => ({
    ...category,
    questions: category.questions.filter(
      q => 
        q.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.answer.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(category => category.questions.length > 0);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Support request submitted",
      description: "We'll respond to your inquiry within 4 hours."
    });
    // Reset form
    setContactForm({
      name: "",
      email: "",
      category: "",
      subject: "",
      message: "",
      priority: "normal"
    });
  };

  const updateForm = (field: string, value: string) => {
    setContactForm(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="container py-8 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-3xl lg:text-4xl font-bold">Help & Support</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Get the help you need, when you need it. Our support team is here 24/7 to ensure 
          your safety and answer any questions about SafeGuard AI.
        </p>
      </div>

      {/* Quick Support Channels */}
      <div className="grid md:grid-cols-3 gap-6">
        {supportChannels.map((channel, index) => {
          const Icon = channel.icon;
          return (
            <Card key={index} className={`relative hover-lift ${channel.recommended ? 'border-primary' : ''}`}>
              {channel.recommended && (
                <Badge className="absolute -top-2 left-4 bg-primary">Recommended</Badge>
              )}
              <CardHeader className="text-center">
                <Icon className="h-12 w-12 mx-auto mb-4 text-primary" />
                <CardTitle>{channel.title}</CardTitle>
                <CardDescription>{channel.description}</CardDescription>
              </CardHeader>
              <CardContent className="text-center space-y-3">
                <div className="space-y-2">
                  <div className="flex items-center justify-center gap-2 text-sm">
                    <Clock className="h-4 w-4" />
                    <span>{channel.availability}</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Response time: {channel.responseTime}
                  </div>
                </div>
                <Button className="w-full">
                  Contact Now
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Emergency Support */}
      <Alert className="border-destructive/50 bg-destructive/10">
        <AlertTriangle className="h-4 w-4 text-destructive" />
        <AlertDescription className="text-destructive">
          <strong>Emergency or Crisis?</strong> If you're experiencing immediate danger or a safety crisis, 
          contact emergency services (911) or use our emergency escalation at{" "}
          <strong>1-800-SAFEGUARD</strong> for immediate assistance.
        </AlertDescription>
      </Alert>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* FAQ Section */}
        <div className="lg:col-span-2 space-y-6">
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold flex items-center gap-2">
              <BookOpen className="h-6 w-6 text-primary" />
              Frequently Asked Questions
            </h2>
            
            {/* Search Bar */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search FAQ..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* FAQ Categories */}
          <div className="space-y-6">
            {filteredFAQs.map((category) => {
              const Icon = category.icon;
              return (
                <Card key={category.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Icon className="h-5 w-5 text-primary" />
                      {category.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Accordion type="single" collapsible className="w-full">
                      {category.questions.map((faq, index) => (
                        <AccordionItem key={index} value={`${category.id}-${index}`}>
                          <AccordionTrigger className="text-left">
                            {faq.question}
                          </AccordionTrigger>
                          <AccordionContent className="text-muted-foreground">
                            {faq.answer}
                          </AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {searchQuery && filteredFAQs.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <HelpCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">No results found</h3>
                <p className="text-muted-foreground mb-4">
                  Couldn't find what you're looking for? Try a different search term or contact our support team.
                </p>
                <Button variant="outline">
                  Contact Support
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Contact Form */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Contact Support</CardTitle>
              <CardDescription>
                Can't find what you're looking for? Send us a message and we'll get back to you quickly.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleFormSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name *</Label>
                    <Input
                      id="name"
                      value={contactForm.name}
                      onChange={(e) => updateForm('name', e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={contactForm.email}
                      onChange={(e) => updateForm('email', e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Category *</Label>
                  <Select value={contactForm.category} onValueChange={(value) => updateForm('category', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="technical">Technical Support</SelectItem>
                      <SelectItem value="billing">Billing & Account</SelectItem>
                      <SelectItem value="feature">Feature Request</SelectItem>
                      <SelectItem value="bug">Bug Report</SelectItem>
                      <SelectItem value="security">Security Concern</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Select value={contactForm.priority} onValueChange={(value) => updateForm('priority', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low - General question</SelectItem>
                      <SelectItem value="normal">Normal - Standard support</SelectItem>
                      <SelectItem value="high">High - Urgent issue</SelectItem>
                      <SelectItem value="critical">Critical - System down</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subject">Subject *</Label>
                  <Input
                    id="subject"
                    value={contactForm.subject}
                    onChange={(e) => updateForm('subject', e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message">Message *</Label>
                  <Textarea
                    id="message"
                    placeholder="Please describe your issue or question in detail..."
                    value={contactForm.message}
                    onChange={(e) => updateForm('message', e.target.value)}
                    className="min-h-32"
                    required
                  />
                </div>

                <Button type="submit" className="w-full">
                  Send Message
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Status & Updates */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-success" />
                System Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">AI Detection System</span>
                <Badge className="status-success">Operational</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Real-time Monitoring</span>
                <Badge className="status-success">Operational</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Alert Notifications</span>
                <Badge className="status-success">Operational</Badge>
              </div>
              <div className="pt-2 border-t">
                <Button variant="outline" className="w-full" size="sm">
                  View Status Page
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Community */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Community Support
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Connect with other SafeGuard AI users, share best practices, and get community support.
              </p>
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start" size="sm">
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Join Discord Community
                </Button>
                <Button variant="outline" className="w-full justify-start" size="sm">
                  <BookOpen className="mr-2 h-4 w-4" />
                  Community Forum
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}