import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, Shield, Eye, TrendingUp, MessageSquare, Mail, Users, Clock } from "lucide-react";

const alertData = [
  {
    id: 1,
    type: "high",
    platform: "Email",
    message: "Aggressive language detected in team communication",
    time: "2 minutes ago",
    status: "active"
  },
  {
    id: 2,
    type: "medium",
    platform: "Chat",
    message: "Repeated negative interactions identified",
    time: "15 minutes ago",
    status: "reviewed"
  },
  {
    id: 3,
    type: "low",
    platform: "Social Media",
    message: "Potential spam or harassment pattern",
    time: "1 hour ago",
    status: "active"
  }
];

const stats = [
  {
    title: "Total Communications Monitored",
    value: "12,847",
    change: "+12.5%",
    icon: Eye
  },
  {
    title: "Threats Detected & Blocked",
    value: "23",
    change: "-8.2%",
    icon: Shield
  },
  {
    title: "Active Alerts",
    value: "3",
    change: "+2",
    icon: AlertTriangle
  },
  {
    title: "Safe Communications",
    value: "99.8%",
    change: "+0.1%",
    icon: TrendingUp
  }
];

export default function Dashboard() {
  const [selectedAlert, setSelectedAlert] = useState<number | null>(null);

  const getAlertColor = (type: string) => {
    switch (type) {
      case "high": return "status-danger";
      case "medium": return "status-warning";
      case "low": return "bg-blue-500 text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  return (
    <div className="container py-8 space-y-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Security Dashboard</h1>
          <p className="text-muted-foreground">
            Real-time monitoring and protection status
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
            Live Monitoring Active
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground">
                  <span className={stat.change.startsWith('+') ? 'text-success' : 'text-destructive'}>
                    {stat.change}
                  </span>
                  {' '}from last period
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Real-time Alerts */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-warning" />
                Active Alerts
              </CardTitle>
              <CardDescription>
                Recent detections requiring attention
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {alertData.map((alert) => (
                <div 
                  key={alert.id}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors hover:bg-muted/50 ${
                    selectedAlert === alert.id ? 'border-primary bg-muted/50' : ''
                  }`}
                  onClick={() => setSelectedAlert(alert.id)}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2">
                        <Badge className={getAlertColor(alert.type)}>
                          {alert.type.toUpperCase()}
                        </Badge>
                        <Badge variant="outline">{alert.platform}</Badge>
                        <span className="text-xs text-muted-foreground">{alert.time}</span>
                      </div>
                      <p className="text-sm">{alert.message}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        Review
                      </Button>
                      <Button size="sm">
                        Take Action
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions & Stats */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>System Health</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>AI Model Accuracy</span>
                  <span>94.8%</span>
                </div>
                <Progress value={94.8} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Response Time</span>
                  <span>0.3s avg</span>
                </div>
                <Progress value={87} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Coverage</span>
                  <span>99.2%</span>
                </div>
                <Progress value={99.2} className="h-2" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full justify-start" variant="outline">
                <MessageSquare className="mr-2 h-4 w-4" />
                Review Flagged Messages
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <Mail className="mr-2 h-4 w-4" />
                Email Reports Summary
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <Users className="mr-2 h-4 w-4" />
                Manage User Settings
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <Clock className="mr-2 h-4 w-4" />
                Schedule Report
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Data Visualization */}
      <Card>
        <CardHeader>
          <CardTitle>Activity Overview</CardTitle>
          <CardDescription>
            Communication patterns and threat detection over time
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="threats" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="threats">Threat Detection</TabsTrigger>
              <TabsTrigger value="volume">Communication Volume</TabsTrigger>
              <TabsTrigger value="platforms">Platform Breakdown</TabsTrigger>
            </TabsList>
            <TabsContent value="threats" className="mt-6">
              <div className="h-64 flex items-center justify-center border rounded-lg bg-muted/50">
                <p className="text-muted-foreground">Interactive threat detection chart would be displayed here</p>
              </div>
            </TabsContent>
            <TabsContent value="volume" className="mt-6">
              <div className="h-64 flex items-center justify-center border rounded-lg bg-muted/50">
                <p className="text-muted-foreground">Communication volume trends would be displayed here</p>
              </div>
            </TabsContent>
            <TabsContent value="platforms" className="mt-6">
              <div className="h-64 flex items-center justify-center border rounded-lg bg-muted/50">
                <p className="text-muted-foreground">Platform usage breakdown would be displayed here</p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}