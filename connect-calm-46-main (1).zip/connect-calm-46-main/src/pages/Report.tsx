import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, Upload, Shield, Phone, Mail, MessageSquare, CheckCircle, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const reportSteps = [
  { id: 1, title: "Incident Details", completed: false },
  { id: 2, title: "Evidence Upload", completed: false },
  { id: 3, title: "Contact Information", completed: false },
  { id: 4, title: "Review & Submit", completed: false }
];

const platformOptions = [
  { value: "email", label: "Email", icon: Mail },
  { value: "chat", label: "Chat/Messaging", icon: MessageSquare },
  { value: "social", label: "Social Media", icon: MessageSquare },
  { value: "forum", label: "Forum/Community", icon: MessageSquare },
  { value: "other", label: "Other", icon: MessageSquare }
];

const severityOptions = [
  { value: "low", label: "Low - Mild inappropriate behavior", color: "bg-blue-500" },
  { value: "medium", label: "Medium - Persistent harassment", color: "bg-yellow-500" },
  { value: "high", label: "High - Severe threats or abuse", color: "bg-red-500" },
  { value: "critical", label: "Critical - Immediate safety concern", color: "bg-red-700" }
];

export default function Report() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    platform: "",
    severity: "",
    incidentType: "",
    description: "",
    location: "",
    frequency: "",
    contactName: "",
    contactEmail: "",
    contactPhone: "",
    anonymous: false,
    consent: false
  });
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);
  const { toast } = useToast();

  const updateFormData = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      const fileNames = Array.from(files).map(file => file.name);
      setUploadedFiles(prev => [...prev, ...fileNames]);
      toast({
        title: "Files uploaded",
        description: `${fileNames.length} file(s) added as evidence.`
      });
    }
  };

  const nextStep = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const submitReport = () => {
    toast({
      title: "Report submitted successfully",
      description: "Your report has been received. Our team will review it within 24 hours."
    });
    // Reset form or redirect
  };

  const progress = (currentStep / 4) * 100;

  return (
    <div className="container py-8 max-w-4xl mx-auto">
      <div className="space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-3xl font-bold">Report Harassment or Abuse</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Your safety is our priority. Use this secure form to report any incidents of harassment, 
            abuse, or threatening behavior. All reports are treated confidentially.
          </p>
        </div>

        {/* Progress Bar */}
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>{Math.round(progress)}% Complete</span>
              </div>
              <Progress value={progress} className="h-2" />
              <div className="flex justify-between">
                {reportSteps.map((step) => (
                  <div 
                    key={step.id}
                    className={`flex items-center space-x-2 text-xs ${
                      step.id <= currentStep ? 'text-primary' : 'text-muted-foreground'
                    }`}
                  >
                    <div className={`w-2 h-2 rounded-full ${
                      step.id < currentStep ? 'bg-success' :
                      step.id === currentStep ? 'bg-primary' : 'bg-muted'
                    }`} />
                    <span className="hidden sm:inline">{step.title}</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Emergency Alert */}
        <Alert className="border-destructive/50 bg-destructive/10">
          <AlertTriangle className="h-4 w-4 text-destructive" />
          <AlertDescription className="text-destructive">
            <strong>Emergency Situation?</strong> If you are in immediate danger, please contact local emergency services (911) 
            or the National Domestic Violence Hotline at 1-800-799-7233.
          </AlertDescription>
        </Alert>

        {/* Form Steps */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Step {currentStep}: {reportSteps[currentStep - 1].title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {currentStep === 1 && (
              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="platform">Platform/Communication Type *</Label>
                  <Select value={formData.platform} onValueChange={(value) => updateFormData('platform', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select the platform where the incident occurred" />
                    </SelectTrigger>
                    <SelectContent>
                      {platformOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          <div className="flex items-center gap-2">
                            <option.icon className="h-4 w-4" />
                            {option.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="severity">Severity Level *</Label>
                  <Select value={formData.severity} onValueChange={(value) => updateFormData('severity', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select the severity of the incident" />
                    </SelectTrigger>
                    <SelectContent>
                      {severityOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          <div className="flex items-center gap-2">
                            <div className={`w-3 h-3 rounded-full ${option.color}`} />
                            {option.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Incident Description *</Label>
                  <Textarea
                    id="description"
                    placeholder="Please provide a detailed description of what happened. Include dates, times, and specific behaviors when possible."
                    value={formData.description}
                    onChange={(e) => updateFormData('description', e.target.value)}
                    className="min-h-32"
                  />
                  <p className="text-xs text-muted-foreground">
                    Be as specific as possible. This information helps our team understand the situation better.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="location">Location/Context</Label>
                    <Input
                      id="location"
                      placeholder="e.g., Work Slack channel, Facebook group"
                      value={formData.location}
                      onChange={(e) => updateFormData('location', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="frequency">Frequency</Label>
                    <Select value={formData.frequency} onValueChange={(value) => updateFormData('frequency', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="How often does this occur?" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="once">One-time incident</SelectItem>
                        <SelectItem value="occasional">Occasional (few times)</SelectItem>
                        <SelectItem value="frequent">Frequent (multiple times per week)</SelectItem>
                        <SelectItem value="daily">Daily or constant</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <Label>Evidence Upload</Label>
                    <p className="text-sm text-muted-foreground mb-4">
                      Upload screenshots, messages, emails, or other evidence that supports your report. 
                      All files are encrypted and stored securely.
                    </p>
                  </div>

                  <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center hover:border-primary/50 transition-colors">
                    <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                    <div className="space-y-2">
                      <p className="text-sm font-medium">Upload Evidence Files</p>
                      <p className="text-xs text-muted-foreground">
                        Drag and drop files here, or click to browse
                      </p>
                      <Input
                        type="file"
                        multiple
                        accept="image/*,video/*,.pdf,.doc,.docx,.txt"
                        onChange={handleFileUpload}
                        className="hidden"
                        id="evidence-upload"
                      />
                      <Button 
                        variant="outline" 
                        onClick={() => document.getElementById('evidence-upload')?.click()}
                      >
                        Choose Files
                      </Button>
                    </div>
                  </div>

                  {uploadedFiles.length > 0 && (
                    <div className="space-y-2">
                      <Label>Uploaded Files ({uploadedFiles.length})</Label>
                      <div className="space-y-2">
                        {uploadedFiles.map((fileName, index) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                            <span className="text-sm truncate">{fileName}</span>
                            <CheckCircle className="h-4 w-4 text-success" />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <Alert>
                    <Shield className="h-4 w-4" />
                    <AlertDescription>
                      Your evidence is encrypted and only accessible to our investigation team. 
                      We recommend including context or annotations when possible.
                    </AlertDescription>
                  </Alert>
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-6">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="anonymous"
                    checked={formData.anonymous}
                    onCheckedChange={(checked) => updateFormData('anonymous', checked)}
                  />
                  <Label htmlFor="anonymous" className="text-sm">
                    Submit this report anonymously
                  </Label>
                </div>

                {!formData.anonymous && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="contactName">Your Name *</Label>
                      <Input
                        id="contactName"
                        placeholder="Full name"
                        value={formData.contactName}
                        onChange={(e) => updateFormData('contactName', e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="contactEmail">Email Address *</Label>
                      <Input
                        id="contactEmail"
                        type="email"
                        placeholder="your.email@example.com"
                        value={formData.contactEmail}
                        onChange={(e) => updateFormData('contactEmail', e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground">
                        We'll use this to send updates about your report
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="contactPhone">Phone Number (Optional)</Label>
                      <Input
                        id="contactPhone"
                        type="tel"
                        placeholder="+1 (555) 123-4567"
                        value={formData.contactPhone}
                        onChange={(e) => updateFormData('contactPhone', e.target.value)}
                      />
                    </div>
                  </div>
                )}

                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    {formData.anonymous 
                      ? "Anonymous reports are processed with the same urgency, but we won't be able to provide updates on the investigation."
                      : "Your contact information is kept confidential and used only for investigation purposes and case updates."
                    }
                  </AlertDescription>
                </Alert>
              </div>
            )}

            {currentStep === 4 && (
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Review Your Report</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Platform</Label>
                      <Badge variant="outline">{formData.platform || 'Not specified'}</Badge>
                    </div>
                    <div className="space-y-2">
                      <Label>Severity</Label>
                      <Badge className={severityOptions.find(s => s.value === formData.severity)?.color || 'bg-gray-500'}>
                        {formData.severity?.toUpperCase() || 'Not specified'}
                      </Badge>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Description</Label>
                    <div className="p-3 bg-muted rounded border text-sm">
                      {formData.description || 'No description provided'}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Evidence Files</Label>
                    <p className="text-sm text-muted-foreground">
                      {uploadedFiles.length} file(s) attached
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label>Contact Information</Label>
                    <p className="text-sm text-muted-foreground">
                      {formData.anonymous ? 'Anonymous submission' : `${formData.contactName} (${formData.contactEmail})`}
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="consent"
                    checked={formData.consent}
                    onCheckedChange={(checked) => updateFormData('consent', checked)}
                  />
                  <Label htmlFor="consent" className="text-sm">
                    I consent to the processing of this report and understand that SafeGuard AI will investigate 
                    this matter according to our privacy policy and terms of service.
                  </Label>
                </div>

                <Alert>
                  <Clock className="h-4 w-4" />
                  <AlertDescription>
                    <strong>What happens next?</strong> Your report will be reviewed by our specialized team within 24 hours. 
                    For urgent matters, initial assessment begins immediately. You'll receive confirmation once submitted.
                  </AlertDescription>
                </Alert>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-8 border-t">
              <Button
                variant="outline"
                onClick={prevStep}
                disabled={currentStep === 1}
              >
                Previous
              </Button>
              
              {currentStep < 4 ? (
                <Button
                  onClick={nextStep}
                  disabled={
                    (currentStep === 1 && (!formData.platform || !formData.severity || !formData.description)) ||
                    (currentStep === 3 && !formData.anonymous && (!formData.contactName || !formData.contactEmail))
                  }
                >
                  Next Step
                </Button>
              ) : (
                <Button
                  onClick={submitReport}
                  disabled={!formData.consent}
                  className="bg-primary hover:bg-primary/90"
                >
                  Submit Report
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Support Resources */}
        <Card>
          <CardHeader>
            <CardTitle>Need Immediate Support?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-primary" />
                <div>
                  <p className="font-medium">Crisis Hotline</p>
                  <p className="text-sm text-muted-foreground">1-800-799-7233</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <MessageSquare className="h-5 w-5 text-primary" />
                <div>
                  <p className="font-medium">Live Chat Support</p>
                  <p className="text-sm text-muted-foreground">Available 24/7</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-primary" />
                <div>
                  <p className="font-medium">Email Support</p>
                  <p className="text-sm text-muted-foreground">support@safeguard-ai.com</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}