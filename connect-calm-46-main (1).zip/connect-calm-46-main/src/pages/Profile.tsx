import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { User, Bell, Shield, History, Settings, Mail, MessageSquare, Twitter } from "lucide-react";

const activityHistory = [
  {
    id: 1,
    type: "threat_detected",
    description: "High-risk harassment detected in email communication",
    timestamp: "2024-01-15 14:30",
    platform: "Email",
    action: "Blocked & Reported"
  },
  {
    id: 2,
    type: "review_completed",
    description: "Completed review of flagged social media interaction",
    timestamp: "2024-01-15 10:15",
    platform: "Twitter",
    action: "Cleared"
  },
  {
    id: 3,
    type: "settings_updated",
    description: "Updated notification preferences",
    timestamp: "2024-01-14 16:45",
    platform: "System",
    action: "Modified"
  }
];

export default function Profile() {
  const [notifications, setNotifications] = useState({
    emailAlerts: true,
    instantAlerts: true,
    weeklyReports: false,
    threatDetection: true
  });

  const [monitoring, setMonitoring] = useState({
    email: true,
    chat: true,
    socialMedia: false,
    forums: false
  });

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "threat_detected": return <Shield className="h-4 w-4 text-destructive" />;
      case "review_completed": return <User className="h-4 w-4 text-success" />;
      case "settings_updated": return <Settings className="h-4 w-4 text-primary" />;
      default: return <History className="h-4 w-4 text-muted-foreground" />;
    }
  };

  return (
    <div className="container py-8 space-y-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Profile & Settings</h1>
          <p className="text-muted-foreground">
            Manage your account and customize your protection preferences
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-8">
        {/* Profile Overview */}
        <Card className="lg:col-span-1">
          <CardHeader className="text-center">
            <Avatar className="w-20 h-20 mx-auto mb-4">
              <AvatarImage src="" />
              <AvatarFallback className="text-lg">JD</AvatarFallback>
            </Avatar>
            <CardTitle>John Doe</CardTitle>
            <CardDescription>john.doe@example.com</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center space-y-2">
              <Badge variant="secondary">Premium Plan</Badge>
              <p className="text-sm text-muted-foreground">
                Member since January 2024
              </p>
            </div>
            <Separator />
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>Protection Level</span>
                <Badge className="status-success">Active</Badge>
              </div>
              <div className="flex justify-between text-sm">
                <span>Monitored Platforms</span>
                <span className="font-medium">2 of 4</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Threats Blocked</span>
                <span className="font-medium">127</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Settings */}
        <div className="lg:col-span-3">
          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
              <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>

            <TabsContent value="profile" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                  <CardDescription>
                    Update your profile information and account settings
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input id="firstName" defaultValue="John" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input id="lastName" defaultValue="Doe" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input id="email" type="email" defaultValue="john.doe@example.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="timezone">Timezone</Label>
                    <Input id="timezone" defaultValue="UTC-8 (Pacific Time)" />
                  </div>
                  <Button>Save Changes</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Account Security</CardTitle>
                  <CardDescription>
                    Manage your password and security preferences
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button variant="outline">Change Password</Button>
                  <Button variant="outline">Enable Two-Factor Authentication</Button>
                  <Button variant="outline">Download Account Data</Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="notifications" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Notification Preferences</CardTitle>
                  <CardDescription>
                    Control how and when you receive alerts and updates
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Email Alerts</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive email notifications for important threats
                      </p>
                    </div>
                    <Switch 
                      checked={notifications.emailAlerts}
                      onCheckedChange={(checked) => 
                        setNotifications(prev => ({ ...prev, emailAlerts: checked }))
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Instant Alerts</Label>
                      <p className="text-sm text-muted-foreground">
                        Real-time push notifications for critical threats
                      </p>
                    </div>
                    <Switch 
                      checked={notifications.instantAlerts}
                      onCheckedChange={(checked) => 
                        setNotifications(prev => ({ ...prev, instantAlerts: checked }))
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Weekly Reports</Label>
                      <p className="text-sm text-muted-foreground">
                        Summary of your protection activity
                      </p>
                    </div>
                    <Switch 
                      checked={notifications.weeklyReports}
                      onCheckedChange={(checked) => 
                        setNotifications(prev => ({ ...prev, weeklyReports: checked }))
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label>Threat Detection Updates</Label>
                      <p className="text-sm text-muted-foreground">
                        Notifications about new AI model improvements
                      </p>
                    </div>
                    <Switch 
                      checked={notifications.threatDetection}
                      onCheckedChange={(checked) => 
                        setNotifications(prev => ({ ...prev, threatDetection: checked }))
                      }
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="monitoring" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Platform Monitoring</CardTitle>
                  <CardDescription>
                    Choose which communication platforms to monitor for threats
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Mail className="h-5 w-5" />
                      <div className="space-y-1">
                        <Label>Email Communications</Label>
                        <p className="text-sm text-muted-foreground">
                          Monitor incoming and outgoing emails
                        </p>
                      </div>
                    </div>
                    <Switch 
                      checked={monitoring.email}
                      onCheckedChange={(checked) => 
                        setMonitoring(prev => ({ ...prev, email: checked }))
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <MessageSquare className="h-5 w-5" />
                      <div className="space-y-1">
                        <Label>Chat & Messaging</Label>
                        <p className="text-sm text-muted-foreground">
                          Monitor chat applications and messaging platforms
                        </p>
                      </div>
                    </div>
                    <Switch 
                      checked={monitoring.chat}
                      onCheckedChange={(checked) => 
                        setMonitoring(prev => ({ ...prev, chat: checked }))
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Twitter className="h-5 w-5" />
                      <div className="space-y-1">
                        <Label>Social Media</Label>
                        <p className="text-sm text-muted-foreground">
                          Monitor mentions and interactions on social platforms
                        </p>
                      </div>
                    </div>
                    <Switch 
                      checked={monitoring.socialMedia}
                      onCheckedChange={(checked) => 
                        setMonitoring(prev => ({ ...prev, socialMedia: checked }))
                      }
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="history" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Activity History</CardTitle>
                  <CardDescription>
                    Review your recent interactions and system activity
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {activityHistory.map((activity) => (
                      <div key={activity.id} className="flex items-start space-x-4 p-4 border rounded-lg">
                        <div className="mt-1">
                          {getActivityIcon(activity.type)}
                        </div>
                        <div className="flex-1 space-y-1">
                          <p className="text-sm font-medium">{activity.description}</p>
                          <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                            <span>{activity.timestamp}</span>
                            <Badge variant="outline" className="text-xs">
                              {activity.platform}
                            </Badge>
                          </div>
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          {activity.action}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}