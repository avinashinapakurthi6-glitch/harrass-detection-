import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { 
  BookOpen, 
  Brain, 
  Shield, 
  Users, 
  Download, 
  Search,
  ExternalLink,
  PlayCircle,
  FileText,
  Lightbulb,
  Heart,
  Phone,
  MessageSquare
} from "lucide-react";

const educationalContent = [
  {
    title: "Recognizing Digital Harassment",
    description: "Learn to identify various forms of online harassment and abusive behavior patterns.",
    type: "Guide",
    readTime: "8 min read",
    category: "Identification",
    icon: Shield
  },
  {
    title: "Protecting Your Digital Privacy",
    description: "Essential steps to secure your online presence and communications.",
    type: "Tutorial",
    readTime: "12 min read",
    category: "Prevention",
    icon: Users
  },
  {
    title: "Understanding AI Detection Technology",
    description: "How machine learning identifies harmful content and protects users.",
    type: "Technical",
    readTime: "15 min read",
    category: "Technology",
    icon: Brain
  },
  {
    title: "Building Supportive Communities",
    description: "Creating safe spaces and fostering positive online interactions.",
    type: "Guide",
    readTime: "10 min read",
    category: "Community",
    icon: Heart
  }
];

const videoResources = [
  {
    title: "SafeGuard AI Platform Overview",
    duration: "5:32",
    description: "Complete walkthrough of dashboard features and real-time monitoring",
    thumbnail: "platform-overview"
  },
  {
    title: "Setting Up Monitoring Preferences",
    duration: "3:45",
    description: "Configure your protection settings for optimal coverage",
    thumbnail: "setup-guide"
  },
  {
    title: "Responding to Detected Threats",
    duration: "7:20",
    description: "Best practices for handling alerts and taking protective action",
    thumbnail: "threat-response"
  }
];

const downloadableResources = [
  {
    title: "Digital Safety Checklist",
    description: "Comprehensive checklist for personal and organizational digital safety",
    format: "PDF",
    size: "2.4 MB"
  },
  {
    title: "Harassment Reporting Template",
    description: "Structured template for documenting incidents effectively",
    format: "DOCX",
    size: "1.1 MB"
  },
  {
    title: "AI Detection Methodology Whitepaper",
    description: "Technical deep-dive into our machine learning approaches",
    format: "PDF",
    size: "5.7 MB"
  }
];

const supportResources = [
  {
    organization: "National Domestic Violence Hotline",
    description: "24/7 confidential support for domestic violence survivors",
    contact: "1-800-799-7233",
    website: "thehotline.org",
    type: "Crisis Support"
  },
  {
    organization: "Cyber Civil Rights Initiative",
    description: "Support for victims of non-consensual intimate image abuse",
    contact: "support@cybercivilrights.org",
    website: "cybercivilrights.org",
    type: "Legal Support"
  },
  {
    organization: "RAINN (Sexual Assault Hotline)",
    description: "National Sexual Assault Hotline providing crisis support",
    contact: "1-800-656-4673",
    website: "rainn.org",
    type: "Crisis Support"
  },
  {
    organization: "Mental Health America",
    description: "Mental health resources and crisis intervention",
    contact: "Text MHA to 741741",
    website: "mhanational.org",
    type: "Mental Health"
  }
];

export default function Resources() {
  return (
    <div className="container py-8 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-3xl lg:text-4xl font-bold">Resources & Support</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Comprehensive resources to help you understand, prevent, and respond to digital harassment. 
          Knowledge is your first line of defense.
        </p>
      </div>

      {/* Search Bar */}
      <div className="max-w-2xl mx-auto">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search resources, guides, and support materials..."
            className="pl-10 h-12"
          />
        </div>
      </div>

      <Tabs defaultValue="education" className="space-y-8">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="education">Education</TabsTrigger>
          <TabsTrigger value="technology">Technology</TabsTrigger>
          <TabsTrigger value="downloads">Downloads</TabsTrigger>
          <TabsTrigger value="support">Support</TabsTrigger>
        </TabsList>

        <TabsContent value="education" className="space-y-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {educationalContent.map((content, index) => {
              const Icon = content.icon;
              return (
                <Card key={index} className="hover-lift cursor-pointer">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">{content.type}</Badge>
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle className="text-lg">{content.title}</CardTitle>
                    <CardDescription>{content.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <span>{content.readTime}</span>
                      <Badge variant="outline">{content.category}</Badge>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Video Resources */}
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <PlayCircle className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-semibold">Video Tutorials</h2>
            </div>
            
            <div className="grid md:grid-cols-3 gap-6">
              {videoResources.map((video, index) => (
                <Card key={index} className="hover-lift cursor-pointer">
                  <div className="aspect-video bg-gradient-primary rounded-t-lg flex items-center justify-center">
                    <PlayCircle className="h-16 w-16 text-white" />
                  </div>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">{video.duration}</Badge>
                    </div>
                    <CardTitle className="text-lg">{video.title}</CardTitle>
                    <CardDescription>{video.description}</CardDescription>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="technology" className="space-y-8">
          <div className="grid lg:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5 text-primary" />
                  AI Detection Technology
                </CardTitle>
                <CardDescription>
                  Understanding how our advanced AI systems identify and prevent harassment
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <div>
                      <h4 className="font-medium">Natural Language Processing</h4>
                      <p className="text-sm text-muted-foreground">
                        Advanced NLP models analyze text for harmful patterns, context, and intent
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <div>
                      <h4 className="font-medium">Behavioral Analysis</h4>
                      <p className="text-sm text-muted-foreground">
                        Machine learning algorithms detect escalating communication patterns
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <div>
                      <h4 className="font-medium">Real-time Processing</h4>
                      <p className="text-sm text-muted-foreground">
                        Sub-second analysis and response to emerging threats
                      </p>
                    </div>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  <FileText className="mr-2 h-4 w-4" />
                  Read Technical Documentation
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-primary" />
                  Privacy & Security
                </CardTitle>
                <CardDescription>
                  How we protect your data while providing comprehensive monitoring
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-success rounded-full mt-2"></div>
                    <div>
                      <h4 className="font-medium">End-to-End Encryption</h4>
                      <p className="text-sm text-muted-foreground">
                        All communications and data are encrypted in transit and at rest
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-success rounded-full mt-2"></div>
                    <div>
                      <h4 className="font-medium">Zero-Knowledge Architecture</h4>
                      <p className="text-sm text-muted-foreground">
                        Our systems analyze patterns without storing personal content
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-success rounded-full mt-2"></div>
                    <div>
                      <h4 className="font-medium">GDPR & CCPA Compliant</h4>
                      <p className="text-sm text-muted-foreground">
                        Full compliance with international privacy regulations
                      </p>
                    </div>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  <ExternalLink className="mr-2 h-4 w-4" />
                  View Privacy Policy
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* FAQ Section */}
          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    question: "How accurate is the AI detection system?",
                    answer: "Our AI system maintains a 94.8% accuracy rate with continuous improvements through machine learning."
                  },
                  {
                    question: "Can the system detect harassment in images or videos?",
                    answer: "Yes, our multimodal AI can analyze visual content for inappropriate material and threatening imagery."
                  },
                  {
                    question: "How does the system handle false positives?",
                    answer: "Users can review and report false positives, which helps train our models for better accuracy."
                  }
                ].map((faq, index) => (
                  <div key={index} className="border-l-4 border-primary/20 pl-4">
                    <h4 className="font-medium mb-2">{faq.question}</h4>
                    <p className="text-sm text-muted-foreground">{faq.answer}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="downloads" className="space-y-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {downloadableResources.map((resource, index) => (
              <Card key={index} className="hover-lift">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <Badge variant="outline">{resource.format}</Badge>
                    <FileText className="h-5 w-5 text-primary" />
                  </div>
                  <CardTitle className="text-lg">{resource.title}</CardTitle>
                  <CardDescription>{resource.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span>File size: {resource.size}</span>
                  </div>
                  <Button className="w-full">
                    <Download className="mr-2 h-4 w-4" />
                    Download
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Additional Resources */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="h-5 w-5 text-primary" />
                Quick Reference Guides
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="font-medium">Emergency Response</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Document evidence immediately</li>
                    <li>• Report to appropriate authorities</li>
                    <li>• Seek support from trusted contacts</li>
                    <li>• Use platform-specific blocking tools</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">Prevention Strategies</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Review privacy settings regularly</li>
                    <li>• Use strong, unique passwords</li>
                    <li>• Enable two-factor authentication</li>
                    <li>• Limit personal information sharing</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="support" className="space-y-8">
          <div className="grid md:grid-cols-2 gap-6">
            {supportResources.map((resource, index) => (
              <Card key={index} className="hover-lift">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary">{resource.type}</Badge>
                    <ExternalLink className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <CardTitle className="text-lg">{resource.organization}</CardTitle>
                  <CardDescription>{resource.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-primary" />
                      <span className="font-medium">{resource.contact}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <ExternalLink className="h-4 w-4 text-primary" />
                      <span className="text-sm text-muted-foreground">{resource.website}</span>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full">
                    Visit Website
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Crisis Support */}
          <Card className="border-destructive/20 bg-destructive/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-destructive">
                <Phone className="h-5 w-5" />
                Immediate Crisis Support
              </CardTitle>
              <CardDescription>
                If you are in immediate danger or experiencing a crisis
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center p-4 border rounded-lg">
                  <Phone className="h-8 w-8 mx-auto mb-2 text-destructive" />
                  <p className="font-semibold">Emergency Services</p>
                  <p className="text-2xl font-bold">911</p>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <MessageSquare className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <p className="font-semibold">Crisis Text Line</p>
                  <p className="text-lg font-bold">Text HOME to 741741</p>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <Phone className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <p className="font-semibold">SafeGuard AI Support</p>
                  <p className="text-lg font-bold">24/7 Available</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}