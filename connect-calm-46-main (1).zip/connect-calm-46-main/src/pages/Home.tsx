import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { Shield, Eye, AlertTriangle, Users, CheckCircle, ArrowRight, Star } from "lucide-react";
import heroImage from "@/assets/hero-image.jpg";

const features = [
  {
    icon: Eye,
    title: "Real-time Monitoring",
    description: "Advanced AI continuously monitors communications across all platforms for signs of harassment and abuse."
  },
  {
    icon: AlertTriangle,
    title: "Instant Alerts",
    description: "Receive immediate notifications when potentially harmful content is detected in your communications."
  },
  {
    icon: Shield,
    title: "Proactive Protection",
    description: "Our system learns and adapts to provide increasingly effective protection against emerging threats."
  },
  {
    icon: Users,
    title: "Community Support",
    description: "Connect with support resources and a community of users working together for safer digital spaces."
  }
];

const testimonials = [
  {
    name: "Sarah Chen",
    role: "Community Manager",
    content: "SafeGuard AI has transformed how we handle online harassment. The real-time detection saved us countless hours.",
    rating: 5
  },
  {
    name: "Marcus Johnson",
    role: "HR Director",
    content: "Finally, a solution that understands the nuances of harmful communication. Our workplace feels safer.",
    rating: 5
  },
  {
    name: "Dr. Elena Rodriguez",
    role: "Digital Safety Researcher",
    content: "The AI's accuracy in detecting subtle forms of harassment is remarkable. This is the future of online safety.",
    rating: 5
  }
];

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-hero py-20 lg:py-32">
        <div className="container relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge variant="secondary" className="w-fit">
                  AI-Powered Protection
                </Badge>
                <h1 className="text-4xl lg:text-6xl font-bold text-white leading-tight">
                  Stop Harassment Before It Starts
                </h1>
                <p className="text-xl text-white/90 leading-relaxed">
                  Advanced AI technology that detects and prevents harassment across all digital communications, 
                  creating safer spaces for everyone.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" asChild className="bg-white text-primary hover:bg-white/90">
                  <Link to="/dashboard">
                    Get Started Free
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10" asChild>
                  <Link to="/resources">
                    Learn More
                  </Link>
                </Button>
              </div>
            </div>
            <div className="lg:order-first">
              <img 
                src={heroImage} 
                alt="AI-powered harassment detection dashboard"
                className="rounded-2xl shadow-strong w-full"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold">How SafeGuard AI Works</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Our comprehensive AI system provides multi-layered protection across all your digital communications.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="text-center hover-lift">
                  <CardHeader>
                    <div className="mx-auto w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-muted/50">
        <div className="container">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold">Trusted by Thousands</h2>
            <p className="text-xl text-muted-foreground">
              See what our users say about SafeGuard AI's impact on their digital safety.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="hover-lift">
                <CardContent className="pt-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                    ))}
                  </div>
                  <blockquote className="text-muted-foreground mb-4">
                    "{testimonial.content}"
                  </blockquote>
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-white">
        <div className="container text-center">
          <div className="max-w-3xl mx-auto space-y-8">
            <h2 className="text-3xl lg:text-4xl font-bold">
              Ready to Create Safer Digital Spaces?
            </h2>
            <p className="text-xl text-white/90">
              Join thousands of organizations already using SafeGuard AI to protect their communities from harassment and abuse.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" asChild>
                <Link to="/dashboard">
                  Start Free Trial
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10" asChild>
                <Link to="/report">
                  Report an Issue
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}