import { useState, useEffect } from 'react'
import { supabase, Communication, Alert, IncidentReport } from '@/lib/supabase'
import { useAuth } from './useAuth'
import { useToast } from '@/hooks/use-toast'

export const useSupabase = () => {
  const { user } = useAuth()
  const { toast } = useToast()

  // Analyze communication
  const analyzeMessage = async (
    message: string,
    communicationType: 'email' | 'chat' | 'social_media' | 'sms',
    senderInfo?: any,
    recipientInfo?: any,
    platformMetadata?: any
  ) => {
    if (!user) throw new Error('User not authenticated')

    const { data, error } = await supabase.functions.invoke('analyze-communication', {
      body: {
        message,
        communicationType,
        senderInfo,
        recipientInfo,
        platformMetadata
      }
    })

    if (error) throw error
    return data
  }

  // Create incident report
  const createReport = async (
    title: string,
    description: string,
    communicationId?: string,
    severity: 'low' | 'medium' | 'high' | 'critical' = 'medium'
  ) => {
    if (!user) throw new Error('User not authenticated')

    const { data, error } = await supabase.functions.invoke('create-incident-report', {
      body: {
        title,
        description,
        communicationId,
        severity
      }
    })

    if (error) throw error

    toast({
      title: "Report Created",
      description: "Your incident report has been submitted successfully.",
    })

    return data
  }

  // Get dashboard data
  const getDashboardData = async () => {
    if (!user) throw new Error('User not authenticated')

    const { data, error } = await supabase.functions.invoke('get-dashboard-data')

    if (error) throw error
    return data.data
  }

  // Mark alert as read
  const markAlertAsRead = async (alertId: string) => {
    const { error } = await supabase
      .from('alerts')
      .update({ is_read: true })
      .eq('id', alertId)

    if (error) throw error
  }

  // Get user settings
  const getUserSettings = async () => {
    if (!user) return null

    const { data, error } = await supabase
      .from('user_settings')
      .select('*')
      .eq('user_id', user.id)
      .single()

    if (error && error.code !== 'PGRST116') { // Not found error is OK
      throw error
    }

    return data
  }

  // Update user settings
  const updateUserSettings = async (settings: Partial<{
    detection_sensitivity: number
    auto_block_enabled: boolean
    real_time_monitoring: boolean
    keywords_to_monitor: string[]
    blocked_contacts: any[]
  }>) => {
    if (!user) throw new Error('User not authenticated')

    const { error } = await supabase
      .from('user_settings')
      .upsert({
        user_id: user.id,
        ...settings,
        updated_at: new Date().toISOString()
      })

    if (error) throw error

    toast({
      title: "Settings Updated",
      description: "Your preferences have been saved successfully.",
    })
  }

  return {
    analyzeMessage,
    createReport,
    getDashboardData,
    markAlertAsRead,
    getUserSettings,
    updateUserSettings
  }
}